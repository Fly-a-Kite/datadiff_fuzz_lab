# DataDiffFuzz Experiment Summary

- Manifest: `runs/experiment-20260514T195546.json`
- Runs: 6
- Presets: null_agg_topk
- Seeds: 15001, 16001, 17001
- Backends: datafusion, duckdb, pandas, polars, polars_lazy, sqlite
- Target suite: core_datafusion,datafusion_cross
- Target suites: core_datafusion, datafusion_cross
- Target families: dataframe:3; embedded_sql:2; query_engine:1
- Common target capabilities: 23
- Aggregate CSV: `/root/datadiff_fuzz_lab/reports/experiment-summary-experiment-20260514T195546-aggregates.csv`
- Triage columns distinguish candidate implementation bugs from documented/expected semantic divergences and oracle false positives.
- Refreshed with current oracle: yes

## Runs

| target suite | preset | seed | cases | findings | candidate bugs | candidate case % | first candidate | semantic divs | false positives | new behavior % | cases/s | data sensitivity | path proxy | frontier | contribution | pruned % | roots | triage |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|---|
| core_datafusion | null_agg_topk | 15001 | 500 | 442 | 442 | 88.4% | 0 | 0 | 0 | 46.0% | 24.93 | 0.99 | 0.74 | 0.63 | 4.70 | 0.0% | grouped_topk_null_sort_key:442 | candidate_implementation_bug:442 |
| core_datafusion | null_agg_topk | 16001 | 500 | 428 | 428 | 85.6% | 0 | 0 | 0 | 48.4% | 24.83 | 1.00 | 0.74 | 0.62 | 4.69 | 0.0% | grouped_topk_null_sort_key:428 | candidate_implementation_bug:428 |
| core_datafusion | null_agg_topk | 17001 | 500 | 415 | 415 | 83.0% | 0 | 0 | 0 | 37.2% | 24.86 | 1.03 | 0.73 | 0.66 | 4.73 | 0.0% | grouped_topk_null_sort_key:415 | candidate_implementation_bug:415 |
| datafusion_cross | null_agg_topk | 15001 | 500 | 434 | 434 | 86.8% | 0 | 0 | 0 | 47.2% | 30.38 | 0.99 | 0.74 | 0.63 | 4.70 | 0.0% | grouped_topk_null_sort_key:434 | candidate_implementation_bug:434 |
| datafusion_cross | null_agg_topk | 16001 | 500 | 431 | 431 | 86.2% | 0 | 0 | 0 | 46.6% | 30.74 | 1.00 | 0.74 | 0.62 | 4.70 | 0.0% | grouped_topk_null_sort_key:431 | candidate_implementation_bug:431 |
| datafusion_cross | null_agg_topk | 17001 | 500 | 412 | 412 | 82.4% | 0 | 0 | 0 | 37.4% | 30.69 | 1.03 | 0.73 | 0.65 | 4.73 | 0.0% | grouped_topk_null_sort_key:412 | candidate_implementation_bug:412 |

## Aggregates

| target suite | preset | runs | cases | findings | candidate bugs | candidate case % | candidate cases/s | median first candidate | semantic divs | false positives | avg new behavior % | avg cases/s | avg data sensitivity | avg path proxy |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| core_datafusion | null_agg_topk | 3 | 1500 | 1285 | 1285 | 85.7% | 21.31 | 0 | 0 | 0 | 43.9% | 24.87 | 1.00 | 0.74 |
| datafusion_cross | null_agg_topk | 3 | 1500 | 1277 | 1277 | 85.1% | 26.05 | 0 | 0 | 0 | 43.7% | 30.60 | 1.00 | 0.74 |

## Candidate Bug-Family Deduplication

Families are conservatively grouped by `root_cause + suspicious_backends`; metamorphic relation failures are mapped to a co-occurring differential root for the same suspicious backend when one exists. Use this table for paper-level bug-family counts; use finding and case counts above for sensitivity and time-to-first measurements.

| target suite | preset | candidate bug families | top families |
|---|---|---:|---|
| core_datafusion | null_agg_topk | 1 | grouped_topk_null_sort_key@datafusion:1285 |
| datafusion_cross | null_agg_topk | 1 | grouped_topk_null_sort_key@datafusion:1277 |

## Interpretation Notes

- Compare `baseline` with `no_type_aware` to measure generator validity and useful behavior discovery.
- Compare `baseline` with `no_normalizer` to estimate false-positive pressure from representation differences.
- Compare `baseline` with `no_feedback` to measure whether corpus feedback improves new behavior discovery.
- Compare `baseline` with `metamorphic` to separate cross-engine differential bugs from single-engine relation violations.
- Use `edge_float` separately from `common`; it studies boundary semantics rather than the default common subset.
