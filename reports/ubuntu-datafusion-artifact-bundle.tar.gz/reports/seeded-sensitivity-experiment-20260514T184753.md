# Seeded Fault Sensitivity Analysis

- Manifest: `runs/experiment-20260514T184753.json`
- Expected roots are counted separately from all candidate findings.

## Targeted Preset Contrasts

| target suite | targeted preset | expected fault case % | delta | ratio | median first expected | first delta |
|---|---|---:|---:|---:|---:|---:|
| seeded_filter | guided_filter | 48.5% | +30.7% | 2.73x | 0 | -3 |
| seeded_groupby | guided_groupby | 66.9% | +35.6% | 2.14x | 0 | -2 |
| seeded_join | guided_join | 33.4% | +26.2% | 4.63x | 2 | -8 |
| seeded_mutate | guided_mutate | 24.6% | +13.7% | 2.26x | 60 | +57 |

## Aggregate Rows

| target suite | preset | cases | expected fault cases | expected fault case % | expected cases/s | median first expected | all candidate case % |
|---|---|---:|---:|---:|---:|---:|---:|
| seeded_filter | baseline | 5000 | 888 | 17.8% | 18.06 | 3 | 26.9% |
| seeded_filter | guided_filter | 5000 | 2425 | 48.5% | 24.67 | 0 | 76.4% |
| seeded_filter | guided_groupby | 5000 | 0 | 0.0% | 0.00 |  | 55.7% |
| seeded_filter | guided_join | 5000 | 777 | 15.5% | 4.38 | 174 | 44.6% |
| seeded_filter | guided_mutate | 5000 | 933 | 18.7% | 9.93 | 0 | 36.9% |
| seeded_groupby | baseline | 5000 | 1566 | 31.3% | 34.44 | 2 | 33.9% |
| seeded_groupby | guided_filter | 5000 | 1198 | 24.0% | 13.20 | 2 | 29.2% |
| seeded_groupby | guided_groupby | 5000 | 3346 | 66.9% | 30.95 | 0 | 80.8% |
| seeded_groupby | guided_join | 5000 | 599 | 12.0% | 3.05 | 17 | 12.3% |
| seeded_groupby | guided_mutate | 5000 | 1173 | 23.5% | 10.70 | 4 | 26.9% |
| seeded_join | baseline | 5000 | 361 | 7.2% | 8.77 | 10 | 10.1% |
| seeded_join | guided_filter | 5000 | 499 | 10.0% | 5.89 | 10 | 19.1% |
| seeded_join | guided_groupby | 5000 | 0 | 0.0% | 0.00 |  | 34.5% |
| seeded_join | guided_join | 5000 | 1670 | 33.4% | 8.80 | 2 | 41.8% |
| seeded_join | guided_mutate | 5000 | 291 | 5.8% | 2.58 | 5 | 12.9% |
| seeded_mutate | baseline | 5000 | 544 | 10.9% | 13.21 | 3 | 24.7% |
| seeded_mutate | guided_filter | 5000 | 0 | 0.0% | 0.00 |  | 51.5% |
| seeded_mutate | guided_groupby | 5000 | 0 | 0.0% | 0.00 |  | 50.2% |
| seeded_mutate | guided_join | 5000 | 164 | 3.3% | 1.34 | 446 | 47.5% |
| seeded_mutate | guided_mutate | 5000 | 1231 | 24.6% | 13.13 | 60 | 66.9% |
