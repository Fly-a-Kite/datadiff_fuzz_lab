# DataDiffFuzz Experiment Analysis

- Manifest: `runs/experiment-20260514T190631.json`
- Aggregate CSV: `/root/datadiff_fuzz_lab/reports/experiment-summary-experiment-20260514T190631-aggregates.csv`
- Baseline preset: `baseline`

## Soundness Snapshot

Non-seeded target suites executed 90000 cases with 4322 findings, 61 candidate implementation bugs, and 4128 oracle false positives.

## Targeted Guidance Contrasts

| target suite | preset | candidate case % | rate delta | rate ratio | candidate cases/s | yield delta | yield ratio | median first | first delta |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|

## All Baseline Comparisons

| target suite | preset | targeted | candidate case % | rate ratio | candidate cases/s | yield ratio | median first |
|---|---|---|---:|---:|---:|---:|---:|
| arrow_cross | guided | no | 0.0% |  | 0.00 |  |  |
| arrow_cross | metamorphic | no | 0.0% |  | 0.00 |  |  |
| arrow_cross | no_feedback | no | 0.0% |  | 0.00 |  |  |
| arrow_cross | no_normalizer | no | 0.0% |  | 0.00 |  |  |
| arrow_cross | no_type_aware | no | 0.2% |  | 0.07 |  | 204 |
| core | guided | no | 0.0% |  | 0.00 |  |  |
| core | metamorphic | no | 0.0% |  | 0.00 |  |  |
| core | no_feedback | no | 0.0% |  | 0.00 |  |  |
| core | no_normalizer | no | 0.0% |  | 0.00 |  |  |
| core | no_type_aware | no | 0.3% |  | 0.09 |  | 20.5 |
| core_arrow | guided | no | 0.0% |  | 0.00 |  |  |
| core_arrow | metamorphic | no | 0.0% |  | 0.00 |  |  |
| core_arrow | no_feedback | no | 0.0% |  | 0.00 |  |  |
| core_arrow | no_normalizer | no | 0.0% |  | 0.00 |  |  |
| core_arrow | no_type_aware | no | 0.4% |  | 0.10 |  | 25 |
| core_datafusion | guided | no | 0.0% | 1.00x | 0.01 | 0.79x | 434 |
| core_datafusion | metamorphic | no | 0.0% | 1.00x | 0.00 | 0.21x | 474 |
| core_datafusion | no_feedback | no | 0.0% | 1.00x | 0.01 | 1.00x | 474 |
| core_datafusion | no_normalizer | no | 0.0% | 0.00x | 0.00 | 0.00x |  |
| core_datafusion | no_type_aware | no | 0.4% | 11.00x | 0.10 | 12.32x | 25 |
| core_lazy | guided | no | 0.0% |  | 0.00 |  |  |
| core_lazy | metamorphic | no | 0.0% |  | 0.00 |  |  |
| core_lazy | no_feedback | no | 0.0% |  | 0.00 |  |  |
| core_lazy | no_normalizer | no | 0.0% |  | 0.00 |  |  |
| core_lazy | no_type_aware | no | 0.4% |  | 0.11 |  | 25 |
| datafusion_cross | guided | no | 0.0% | 1.00x | 0.01 | 0.76x | 434 |
| datafusion_cross | metamorphic | no | 0.0% | 1.00x | 0.00 | 0.21x | 474 |
| datafusion_cross | no_feedback | no | 0.0% | 1.00x | 0.01 | 1.01x | 474 |
| datafusion_cross | no_normalizer | no | 0.0% | 1.00x | 0.01 | 1.00x | 481 |
| datafusion_cross | no_type_aware | no | 0.3% | 8.00x | 0.09 | 8.95x | 93 |
