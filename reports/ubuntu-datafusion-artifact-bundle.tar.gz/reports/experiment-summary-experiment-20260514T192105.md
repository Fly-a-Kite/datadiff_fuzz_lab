# DataDiffFuzz Experiment Summary

- Manifest: `runs/experiment-20260514T192105.json`
- Runs: 60
- Presets: null_groupby_topk, null_agg_topk, float_group_key, float_group_key_metamorphic
- Seeds: 5001, 6001, 7001, 8001, 9001
- Backends: datafusion, duckdb, pandas, polars, polars_lazy, sqlite
- Target suite: core_datafusion,core_lazy,datafusion_cross
- Target suites: core_datafusion, core_lazy, datafusion_cross
- Target families: dataframe:3; embedded_sql:2; query_engine:1
- Common target capabilities: 23
- Aggregate CSV: `/root/datadiff_fuzz_lab/reports/experiment-summary-experiment-20260514T192105-aggregates.csv`
- Triage columns distinguish candidate implementation bugs from documented/expected semantic divergences and oracle false positives.
- Refreshed with current oracle: yes

## Runs

| target suite | preset | seed | cases | findings | candidate bugs | candidate case % | first candidate | semantic divs | false positives | new behavior % | cases/s | data sensitivity | path proxy | frontier | contribution | pruned % | roots | triage |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|---|
| core_datafusion | null_groupby_topk | 5001 | 1000 | 716 | 716 | 71.6% | 0 | 0 | 0 | 11.1% | 21.29 | 1.13 | 0.83 | 0.60 | 4.42 | 0.0% | grouped_topk_null_sort_key:716 | candidate_implementation_bug:716 |
| core_datafusion | null_groupby_topk | 6001 | 1000 | 759 | 759 | 75.9% | 0 | 0 | 0 | 11.2% | 21.28 | 1.12 | 0.83 | 0.60 | 4.41 | 0.0% | grouped_topk_null_sort_key:759 | candidate_implementation_bug:759 |
| core_datafusion | null_groupby_topk | 7001 | 1000 | 751 | 751 | 75.1% | 0 | 0 | 0 | 10.8% | 21.33 | 1.12 | 0.83 | 0.60 | 4.42 | 0.0% | grouped_topk_null_sort_key:751 | candidate_implementation_bug:751 |
| core_datafusion | null_groupby_topk | 8001 | 1000 | 741 | 741 | 74.1% | 0 | 0 | 0 | 10.4% | 21.10 | 1.13 | 0.83 | 0.60 | 4.42 | 0.0% | grouped_topk_null_sort_key:741 | candidate_implementation_bug:741 |
| core_datafusion | null_groupby_topk | 9001 | 1000 | 728 | 728 | 72.8% | 0 | 0 | 0 | 10.3% | 21.02 | 1.12 | 0.83 | 0.60 | 4.42 | 0.0% | grouped_topk_null_sort_key:728 | candidate_implementation_bug:728 |
| core_datafusion | null_agg_topk | 5001 | 1000 | 625 | 625 | 62.5% | 1 | 0 | 0 | 38.8% | 21.56 | 1.00 | 0.71 | 0.62 | 4.67 | 0.0% | grouped_topk_null_sort_key:625 | candidate_implementation_bug:625 |
| core_datafusion | null_agg_topk | 6001 | 1000 | 608 | 608 | 60.8% | 0 | 0 | 0 | 39.4% | 21.69 | 0.98 | 0.71 | 0.63 | 4.69 | 0.0% | grouped_topk_null_sort_key:608 | candidate_implementation_bug:608 |
| core_datafusion | null_agg_topk | 7001 | 1000 | 610 | 610 | 61.0% | 0 | 0 | 0 | 39.5% | 21.76 | 0.97 | 0.71 | 0.61 | 4.67 | 0.0% | grouped_topk_null_sort_key:610 | candidate_implementation_bug:610 |
| core_datafusion | null_agg_topk | 8001 | 1000 | 604 | 604 | 60.4% | 1 | 0 | 0 | 40.5% | 21.77 | 0.99 | 0.71 | 0.61 | 4.67 | 0.0% | grouped_topk_null_sort_key:604 | candidate_implementation_bug:604 |
| core_datafusion | null_agg_topk | 9001 | 1000 | 589 | 589 | 58.9% | 0 | 0 | 0 | 40.7% | 21.68 | 0.98 | 0.71 | 0.61 | 4.67 | 0.0% | grouped_topk_null_sort_key:589 | candidate_implementation_bug:589 |
| core_datafusion | float_group_key | 5001 | 1000 | 1 | 1 | 0.1% | 995 | 0 | 0 | 24.1% | 13.76 | 1.44 | 0.94 | 0.74 | 5.80 | 0.0% | grouped_topk_null_sort_key:1 | candidate_implementation_bug:1 |
| core_datafusion | float_group_key | 6001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 25.2% | 13.48 | 1.44 | 0.94 | 0.75 | 5.85 | 0.0% | none | none |
| core_datafusion | float_group_key | 7001 | 1000 | 23 | 23 | 2.3% | 143 | 0 | 0 | 25.7% | 13.43 | 1.44 | 0.95 | 0.74 | 5.82 | 0.0% | grouped_topk_null_sort_key:23 | candidate_implementation_bug:23 |
| core_datafusion | float_group_key | 8001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 21.8% | 13.76 | 1.44 | 0.92 | 0.74 | 5.81 | 0.0% | none | none |
| core_datafusion | float_group_key | 9001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 25.4% | 13.66 | 1.44 | 0.92 | 0.75 | 5.84 | 0.0% | none | none |
| core_datafusion | float_group_key_metamorphic | 5001 | 1000 | 1 | 1 | 0.1% | 995 | 0 | 0 | 24.1% | 1.58 | 1.44 | 0.94 | 0.74 | 5.80 | 0.0% | grouped_topk_null_sort_key:1 | candidate_implementation_bug:1 |
| core_datafusion | float_group_key_metamorphic | 6001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 25.2% | 1.56 | 1.44 | 0.94 | 0.75 | 5.85 | 0.0% | none | none |
| core_datafusion | float_group_key_metamorphic | 7001 | 1000 | 23 | 23 | 2.3% | 143 | 0 | 0 | 25.7% | 1.56 | 1.44 | 0.95 | 0.74 | 5.82 | 0.0% | grouped_topk_null_sort_key:23 | candidate_implementation_bug:23 |
| core_datafusion | float_group_key_metamorphic | 8001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 21.8% | 1.61 | 1.44 | 0.92 | 0.74 | 5.81 | 0.0% | none | none |
| core_datafusion | float_group_key_metamorphic | 9001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 25.4% | 1.59 | 1.44 | 0.92 | 0.75 | 5.84 | 0.0% | none | none |
| core_lazy | null_groupby_topk | 5001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 11.7% | 25.94 | 1.16 | 0.83 | 0.61 | 4.43 | 0.0% | none | none |
| core_lazy | null_groupby_topk | 6001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 12.6% | 26.03 | 1.14 | 0.83 | 0.60 | 4.42 | 0.0% | none | none |
| core_lazy | null_groupby_topk | 7001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 10.2% | 26.33 | 1.13 | 0.83 | 0.60 | 4.41 | 0.0% | none | none |
| core_lazy | null_groupby_topk | 8001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 10.8% | 26.25 | 1.13 | 0.84 | 0.60 | 4.41 | 0.0% | none | none |
| core_lazy | null_groupby_topk | 9001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 9.4% | 25.97 | 1.13 | 0.84 | 0.59 | 4.41 | 0.0% | none | none |
| core_lazy | null_agg_topk | 5001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 45.9% | 26.14 | 0.97 | 0.70 | 0.65 | 4.71 | 0.0% | none | none |
| core_lazy | null_agg_topk | 6001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 44.7% | 26.42 | 0.97 | 0.71 | 0.64 | 4.70 | 0.0% | none | none |
| core_lazy | null_agg_topk | 7001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 45.3% | 26.65 | 0.96 | 0.71 | 0.64 | 4.70 | 0.0% | none | none |
| core_lazy | null_agg_topk | 8001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 46.2% | 26.88 | 0.96 | 0.70 | 0.63 | 4.69 | 0.0% | none | none |
| core_lazy | null_agg_topk | 9001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 47.7% | 27.25 | 0.96 | 0.71 | 0.64 | 4.69 | 0.0% | none | none |
| core_lazy | float_group_key | 5001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 24.2% | 17.01 | 1.44 | 0.94 | 0.74 | 5.80 | 0.0% | none | none |
| core_lazy | float_group_key | 6001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 25.2% | 16.80 | 1.44 | 0.94 | 0.75 | 5.85 | 0.0% | none | none |
| core_lazy | float_group_key | 7001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 27.4% | 16.94 | 1.44 | 0.95 | 0.75 | 5.83 | 0.0% | none | none |
| core_lazy | float_group_key | 8001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 21.8% | 17.18 | 1.44 | 0.92 | 0.74 | 5.81 | 0.0% | none | none |
| core_lazy | float_group_key | 9001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 25.4% | 16.97 | 1.44 | 0.92 | 0.75 | 5.84 | 0.0% | none | none |
| core_lazy | float_group_key_metamorphic | 5001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 24.2% | 2.00 | 1.44 | 0.94 | 0.74 | 5.80 | 0.0% | none | none |
| core_lazy | float_group_key_metamorphic | 6001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 25.2% | 1.98 | 1.44 | 0.94 | 0.75 | 5.85 | 0.0% | none | none |
| core_lazy | float_group_key_metamorphic | 7001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 27.4% | 1.99 | 1.44 | 0.95 | 0.75 | 5.83 | 0.0% | none | none |
| core_lazy | float_group_key_metamorphic | 8001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 21.8% | 2.03 | 1.44 | 0.92 | 0.74 | 5.81 | 0.0% | none | none |
| core_lazy | float_group_key_metamorphic | 9001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 25.4% | 2.02 | 1.44 | 0.92 | 0.75 | 5.84 | 0.0% | none | none |
| datafusion_cross | null_groupby_topk | 5001 | 1000 | 723 | 723 | 72.3% | 0 | 0 | 0 | 11.7% | 25.20 | 1.13 | 0.83 | 0.61 | 4.42 | 0.0% | grouped_topk_null_sort_key:723 | candidate_implementation_bug:723 |
| datafusion_cross | null_groupby_topk | 6001 | 1000 | 744 | 744 | 74.4% | 0 | 0 | 0 | 12.0% | 26.13 | 1.12 | 0.83 | 0.60 | 4.42 | 0.0% | grouped_topk_null_sort_key:744 | candidate_implementation_bug:744 |
| datafusion_cross | null_groupby_topk | 7001 | 1000 | 753 | 753 | 75.3% | 0 | 0 | 0 | 10.1% | 26.59 | 1.12 | 0.83 | 0.60 | 4.42 | 0.0% | grouped_topk_null_sort_key:753 | candidate_implementation_bug:753 |
| datafusion_cross | null_groupby_topk | 8001 | 1000 | 752 | 752 | 75.2% | 0 | 0 | 0 | 10.5% | 26.85 | 1.13 | 0.83 | 0.60 | 4.41 | 0.0% | grouped_topk_null_sort_key:752 | candidate_implementation_bug:752 |
| datafusion_cross | null_groupby_topk | 9001 | 1000 | 735 | 735 | 73.5% | 0 | 0 | 0 | 10.4% | 26.95 | 1.12 | 0.83 | 0.61 | 4.42 | 0.0% | grouped_topk_null_sort_key:735 | candidate_implementation_bug:735 |
| datafusion_cross | null_agg_topk | 5001 | 1000 | 626 | 626 | 62.6% | 1 | 0 | 0 | 41.6% | 28.27 | 0.99 | 0.71 | 0.61 | 4.67 | 0.0% | grouped_topk_null_sort_key:626 | candidate_implementation_bug:626 |
| datafusion_cross | null_agg_topk | 6001 | 1000 | 605 | 605 | 60.5% | 0 | 0 | 0 | 40.4% | 28.62 | 0.98 | 0.71 | 0.62 | 4.69 | 0.0% | grouped_topk_null_sort_key:605 | candidate_implementation_bug:605 |
| datafusion_cross | null_agg_topk | 7001 | 1000 | 610 | 610 | 61.0% | 0 | 0 | 0 | 41.3% | 28.82 | 0.98 | 0.71 | 0.61 | 4.67 | 0.0% | grouped_topk_null_sort_key:610 | candidate_implementation_bug:610 |
| datafusion_cross | null_agg_topk | 8001 | 1000 | 621 | 621 | 62.1% | 1 | 0 | 0 | 42.3% | 28.86 | 0.99 | 0.71 | 0.61 | 4.67 | 0.0% | grouped_topk_null_sort_key:621 | candidate_implementation_bug:621 |
| datafusion_cross | null_agg_topk | 9001 | 1000 | 605 | 605 | 60.5% | 0 | 0 | 0 | 40.8% | 30.39 | 0.98 | 0.71 | 0.62 | 4.67 | 0.0% | grouped_topk_null_sort_key:605 | candidate_implementation_bug:605 |
| datafusion_cross | float_group_key | 5001 | 1000 | 1 | 1 | 0.1% | 995 | 0 | 0 | 24.1% | 15.29 | 1.44 | 0.94 | 0.74 | 5.80 | 0.0% | grouped_topk_null_sort_key:1 | candidate_implementation_bug:1 |
| datafusion_cross | float_group_key | 6001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 25.2% | 15.38 | 1.44 | 0.94 | 0.75 | 5.85 | 0.0% | none | none |
| datafusion_cross | float_group_key | 7001 | 1000 | 23 | 23 | 2.3% | 143 | 0 | 0 | 25.7% | 15.22 | 1.44 | 0.95 | 0.74 | 5.82 | 0.0% | grouped_topk_null_sort_key:23 | candidate_implementation_bug:23 |
| datafusion_cross | float_group_key | 8001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 21.8% | 15.71 | 1.44 | 0.92 | 0.74 | 5.81 | 0.0% | none | none |
| datafusion_cross | float_group_key | 9001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 25.4% | 15.40 | 1.44 | 0.92 | 0.75 | 5.84 | 0.0% | none | none |
| datafusion_cross | float_group_key_metamorphic | 5001 | 1000 | 1 | 1 | 0.1% | 995 | 0 | 0 | 24.1% | 1.83 | 1.44 | 0.94 | 0.74 | 5.80 | 0.0% | grouped_topk_null_sort_key:1 | candidate_implementation_bug:1 |
| datafusion_cross | float_group_key_metamorphic | 6001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 25.2% | 1.81 | 1.44 | 0.94 | 0.75 | 5.85 | 0.0% | none | none |
| datafusion_cross | float_group_key_metamorphic | 7001 | 1000 | 23 | 23 | 2.3% | 143 | 0 | 0 | 25.7% | 1.79 | 1.44 | 0.95 | 0.74 | 5.82 | 0.0% | grouped_topk_null_sort_key:23 | candidate_implementation_bug:23 |
| datafusion_cross | float_group_key_metamorphic | 8001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 21.8% | 1.85 | 1.44 | 0.92 | 0.74 | 5.81 | 0.0% | none | none |
| datafusion_cross | float_group_key_metamorphic | 9001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 25.4% | 1.82 | 1.44 | 0.92 | 0.75 | 5.84 | 0.0% | none | none |

## Aggregates

| target suite | preset | runs | cases | findings | candidate bugs | candidate case % | candidate cases/s | median first candidate | semantic divs | false positives | avg new behavior % | avg cases/s | avg data sensitivity | avg path proxy |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| core_datafusion | float_group_key | 5 | 5000 | 24 | 24 | 0.5% | 0.07 | 569 | 0 | 0 | 24.4% | 13.62 | 1.44 | 0.93 |
| core_datafusion | float_group_key_metamorphic | 5 | 5000 | 24 | 24 | 0.5% | 0.01 | 569 | 0 | 0 | 24.4% | 1.58 | 1.44 | 0.93 |
| core_datafusion | null_agg_topk | 5 | 5000 | 3036 | 3036 | 60.7% | 13.17 | 0 | 0 | 0 | 39.8% | 21.69 | 0.98 | 0.71 |
| core_datafusion | null_groupby_topk | 5 | 5000 | 3695 | 3695 | 73.9% | 15.67 | 0 | 0 | 0 | 10.8% | 21.20 | 1.12 | 0.83 |
| core_lazy | float_group_key | 5 | 5000 | 0 | 0 | 0.0% | 0.00 |  | 0 | 0 | 24.8% | 16.98 | 1.44 | 0.93 |
| core_lazy | float_group_key_metamorphic | 5 | 5000 | 0 | 0 | 0.0% | 0.00 |  | 0 | 0 | 24.8% | 2.00 | 1.44 | 0.93 |
| core_lazy | null_agg_topk | 5 | 5000 | 0 | 0 | 0.0% | 0.00 |  | 0 | 0 | 46.0% | 26.67 | 0.97 | 0.71 |
| core_lazy | null_groupby_topk | 5 | 5000 | 0 | 0 | 0.0% | 0.00 |  | 0 | 0 | 10.9% | 26.11 | 1.14 | 0.83 |
| datafusion_cross | float_group_key | 5 | 5000 | 24 | 24 | 0.5% | 0.07 | 569 | 0 | 0 | 24.4% | 15.40 | 1.44 | 0.93 |
| datafusion_cross | float_group_key_metamorphic | 5 | 5000 | 24 | 24 | 0.5% | 0.01 | 569 | 0 | 0 | 24.4% | 1.82 | 1.44 | 0.93 |
| datafusion_cross | null_agg_topk | 5 | 5000 | 3067 | 3067 | 61.3% | 17.78 | 0 | 0 | 0 | 41.3% | 28.99 | 0.99 | 0.71 |
| datafusion_cross | null_groupby_topk | 5 | 5000 | 3707 | 3707 | 74.1% | 19.53 | 0 | 0 | 0 | 10.9% | 26.34 | 1.12 | 0.83 |

## Candidate Bug-Family Deduplication

Families are conservatively grouped by `root_cause + suspicious_backends`; metamorphic relation failures are mapped to a co-occurring differential root for the same suspicious backend when one exists. Use this table for paper-level bug-family counts; use finding and case counts above for sensitivity and time-to-first measurements.

| target suite | preset | candidate bug families | top families |
|---|---|---:|---|
| core_datafusion | float_group_key | 1 | grouped_topk_null_sort_key@datafusion:24 |
| core_datafusion | float_group_key_metamorphic | 1 | grouped_topk_null_sort_key@datafusion:24 |
| core_datafusion | null_agg_topk | 1 | grouped_topk_null_sort_key@datafusion:3036 |
| core_datafusion | null_groupby_topk | 1 | grouped_topk_null_sort_key@datafusion:3695 |
| core_lazy | float_group_key | 0 | none |
| core_lazy | float_group_key_metamorphic | 0 | none |
| core_lazy | null_agg_topk | 0 | none |
| core_lazy | null_groupby_topk | 0 | none |
| datafusion_cross | float_group_key | 1 | grouped_topk_null_sort_key@datafusion:24 |
| datafusion_cross | float_group_key_metamorphic | 1 | grouped_topk_null_sort_key@datafusion:24 |
| datafusion_cross | null_agg_topk | 1 | grouped_topk_null_sort_key@datafusion:3067 |
| datafusion_cross | null_groupby_topk | 1 | grouped_topk_null_sort_key@datafusion:3707 |

## Interpretation Notes

- Compare `baseline` with `no_type_aware` to measure generator validity and useful behavior discovery.
- Compare `baseline` with `no_normalizer` to estimate false-positive pressure from representation differences.
- Compare `baseline` with `no_feedback` to measure whether corpus feedback improves new behavior discovery.
- Compare `baseline` with `metamorphic` to separate cross-engine differential bugs from single-engine relation violations.
- Use `edge_float` separately from `common`; it studies boundary semantics rather than the default common subset.
