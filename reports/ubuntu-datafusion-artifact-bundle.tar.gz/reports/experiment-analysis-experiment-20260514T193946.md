# DataDiffFuzz Experiment Analysis

- Manifest: `runs/experiment-20260514T193946.json`
- Aggregate CSV: `/root/datadiff_fuzz_lab/reports/experiment-summary-experiment-20260514T193946-aggregates.csv`
- Baseline preset: `bughunt_no_groupby`

## Soundness Snapshot

Non-seeded target suites executed 36000 cases with 0 findings, 0 candidate implementation bugs, and 0 oracle false positives.

## Targeted Guidance Contrasts

| target suite | preset | candidate case % | rate delta | rate ratio | candidate cases/s | yield delta | yield ratio | median first | first delta |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|

## All Baseline Comparisons

| target suite | preset | targeted | candidate case % | rate ratio | candidate cases/s | yield ratio | median first |
|---|---|---|---:|---:|---:|---:|---:|
| arrow_cross | bughunt_no_groupby_guided | no | 0.0% |  | 0.00 |  |  |
| arrow_cross | bughunt_no_groupby_metamorphic | no | 0.0% |  | 0.00 |  |  |
| core | bughunt_no_groupby_guided | no | 0.0% |  | 0.00 |  |  |
| core | bughunt_no_groupby_metamorphic | no | 0.0% |  | 0.00 |  |  |
| core_arrow | bughunt_no_groupby_guided | no | 0.0% |  | 0.00 |  |  |
| core_arrow | bughunt_no_groupby_metamorphic | no | 0.0% |  | 0.00 |  |  |
| core_lazy | bughunt_no_groupby_guided | no | 0.0% |  | 0.00 |  |  |
| core_lazy | bughunt_no_groupby_metamorphic | no | 0.0% |  | 0.00 |  |  |
