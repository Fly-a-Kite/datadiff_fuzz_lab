# DataDiffFuzz Experiment Summary

- Manifest: `runs/experiment-20260514T181521.json`
- Runs: 2
- Presets: null_groupby_topk
- Seeds: 21, 1021
- Backends: datafusion, duckdb, pandas
- Target suite: datafusion_cross
- Target suites: datafusion_cross
- Target families: query_engine:1; embedded_sql:1; dataframe:1
- Common target capabilities: 23
- Aggregate CSV: `/root/datadiff_fuzz_lab/reports/experiment-summary-experiment-20260514T181521-aggregates.csv`
- Triage columns distinguish candidate implementation bugs from documented/expected semantic divergences and oracle false positives.
- Refreshed with current oracle: yes

## Runs

| target suite | preset | seed | cases | findings | candidate bugs | candidate case % | first candidate | semantic divs | false positives | new behavior % | cases/s | data sensitivity | path proxy | frontier | contribution | pruned % | roots | triage |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|---|
| datafusion_cross | null_groupby_topk | 21 | 50 | 33 | 33 | 66.0% | 1 | 0 | 0 | 38.0% | 27.02 | 1.21 | 1.23 | 0.67 | 4.79 | 0.0% | grouped_topk_null_sort_key:33 | candidate_implementation_bug:33 |
| datafusion_cross | null_groupby_topk | 1021 | 50 | 42 | 42 | 84.0% | 1 | 0 | 0 | 34.0% | 25.06 | 1.22 | 1.20 | 0.69 | 4.80 | 0.0% | grouped_topk_null_sort_key:42 | candidate_implementation_bug:42 |

## Aggregates

| target suite | preset | runs | cases | findings | candidate bugs | candidate case % | candidate cases/s | median first candidate | semantic divs | false positives | avg new behavior % | avg cases/s | avg data sensitivity | avg path proxy |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| datafusion_cross | null_groupby_topk | 2 | 100 | 75 | 75 | 75.0% | 19.53 | 1 | 0 | 0 | 36.0% | 26.04 | 1.21 | 1.21 |

## Candidate Bug-Family Deduplication

Families are conservatively grouped by `root_cause + suspicious_backends`; metamorphic relation failures are mapped to a co-occurring differential root for the same suspicious backend when one exists. Use this table for paper-level bug-family counts; use finding and case counts above for sensitivity and time-to-first measurements.

| target suite | preset | candidate bug families | top families |
|---|---|---:|---|
| datafusion_cross | null_groupby_topk | 1 | grouped_topk_null_sort_key@datafusion:75 |

## Interpretation Notes

- Compare `baseline` with `no_type_aware` to measure generator validity and useful behavior discovery.
- Compare `baseline` with `no_normalizer` to estimate false-positive pressure from representation differences.
- Compare `baseline` with `no_feedback` to measure whether corpus feedback improves new behavior discovery.
- Compare `baseline` with `metamorphic` to separate cross-engine differential bugs from single-engine relation violations.
- Use `edge_float` separately from `common`; it studies boundary semantics rather than the default common subset.
