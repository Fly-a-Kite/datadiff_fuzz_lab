# DataDiffFuzz Experiment Summary

- Manifest: `runs/experiment-20260514T180106.json`
- Runs: 20
- Presets: null_groupby_topk, null_agg_topk
- Seeds: 11, 1011, 2011, 3011, 4011
- Backends: datafusion, duckdb, pandas, polars, polars_lazy, sqlite
- Target suite: core_datafusion,datafusion_cross
- Target suites: core_datafusion, datafusion_cross
- Target families: dataframe:3; embedded_sql:2; query_engine:1
- Common target capabilities: 23
- Aggregate CSV: `/root/datadiff_fuzz_lab/reports/experiment-summary-experiment-20260514T180106-aggregates.csv`
- Triage columns distinguish candidate implementation bugs from documented/expected semantic divergences and oracle false positives.
- Refreshed with current oracle: yes

## Runs

| target suite | preset | seed | cases | findings | candidate bugs | candidate case % | first candidate | semantic divs | false positives | new behavior % | cases/s | data sensitivity | path proxy | frontier | contribution | pruned % | roots | triage |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|---|
| core_datafusion | null_groupby_topk | 11 | 500 | 377 | 377 | 75.4% | 0 | 0 | 0 | 14.4% | 21.64 | 1.13 | 0.86 | 0.61 | 4.44 | 0.0% | grouped_topk_null_sort_key:377 | candidate_implementation_bug:377 |
| core_datafusion | null_groupby_topk | 1011 | 500 | 395 | 395 | 79.0% | 1 | 0 | 0 | 15.0% | 21.65 | 1.13 | 0.86 | 0.61 | 4.44 | 0.0% | grouped_topk_null_sort_key:395 | candidate_implementation_bug:395 |
| core_datafusion | null_groupby_topk | 2011 | 500 | 395 | 395 | 79.0% | 0 | 0 | 0 | 13.0% | 21.68 | 1.13 | 0.86 | 0.61 | 4.45 | 0.0% | grouped_topk_null_sort_key:395 | candidate_implementation_bug:395 |
| core_datafusion | null_groupby_topk | 3011 | 500 | 370 | 370 | 74.0% | 0 | 0 | 0 | 15.0% | 22.03 | 1.13 | 0.86 | 0.60 | 4.44 | 0.0% | grouped_topk_null_sort_key:370 | candidate_implementation_bug:370 |
| core_datafusion | null_groupby_topk | 4011 | 500 | 377 | 377 | 75.4% | 0 | 0 | 0 | 14.6% | 21.56 | 1.13 | 0.86 | 0.62 | 4.45 | 0.0% | grouped_topk_null_sort_key:377 | candidate_implementation_bug:377 |
| core_datafusion | null_agg_topk | 11 | 500 | 295 | 295 | 59.0% | 4 | 0 | 0 | 41.0% | 22.36 | 0.99 | 0.74 | 0.61 | 4.68 | 0.0% | grouped_topk_null_sort_key:295 | candidate_implementation_bug:295 |
| core_datafusion | null_agg_topk | 1011 | 500 | 292 | 292 | 58.4% | 1 | 0 | 0 | 50.0% | 22.20 | 0.98 | 0.73 | 0.62 | 4.69 | 0.0% | grouped_topk_null_sort_key:292 | candidate_implementation_bug:292 |
| core_datafusion | null_agg_topk | 2011 | 500 | 286 | 286 | 57.2% | 4 | 0 | 0 | 52.4% | 22.44 | 0.98 | 0.73 | 0.63 | 4.70 | 0.0% | grouped_topk_null_sort_key:286 | candidate_implementation_bug:286 |
| core_datafusion | null_agg_topk | 3011 | 500 | 252 | 252 | 50.4% | 0 | 0 | 0 | 49.6% | 22.45 | 0.99 | 0.73 | 0.62 | 4.70 | 0.0% | grouped_topk_null_sort_key:252 | candidate_implementation_bug:252 |
| core_datafusion | null_agg_topk | 4011 | 500 | 324 | 324 | 64.8% | 0 | 0 | 0 | 39.4% | 22.16 | 0.97 | 0.73 | 0.67 | 4.75 | 0.0% | grouped_topk_null_sort_key:324 | candidate_implementation_bug:324 |
| datafusion_cross | null_groupby_topk | 11 | 500 | 376 | 376 | 75.2% | 0 | 0 | 0 | 13.8% | 24.54 | 1.13 | 0.86 | 0.61 | 4.44 | 0.0% | grouped_topk_null_sort_key:376 | candidate_implementation_bug:376 |
| datafusion_cross | null_groupby_topk | 1011 | 500 | 395 | 395 | 79.0% | 1 | 0 | 0 | 15.6% | 24.37 | 1.12 | 0.86 | 0.61 | 4.44 | 0.0% | grouped_topk_null_sort_key:395 | candidate_implementation_bug:395 |
| datafusion_cross | null_groupby_topk | 2011 | 500 | 395 | 395 | 79.0% | 0 | 0 | 0 | 13.2% | 24.31 | 1.13 | 0.86 | 0.61 | 4.45 | 0.0% | grouped_topk_null_sort_key:395 | candidate_implementation_bug:395 |
| datafusion_cross | null_groupby_topk | 3011 | 500 | 370 | 370 | 74.0% | 0 | 0 | 0 | 14.6% | 24.37 | 1.13 | 0.86 | 0.61 | 4.44 | 0.0% | grouped_topk_null_sort_key:370 | candidate_implementation_bug:370 |
| datafusion_cross | null_groupby_topk | 4011 | 500 | 373 | 373 | 74.6% | 0 | 0 | 0 | 14.4% | 24.11 | 1.13 | 0.86 | 0.62 | 4.45 | 0.0% | grouped_topk_null_sort_key:373 | candidate_implementation_bug:373 |
| datafusion_cross | null_agg_topk | 11 | 500 | 296 | 296 | 59.2% | 4 | 0 | 0 | 41.8% | 25.82 | 0.99 | 0.74 | 0.60 | 4.68 | 0.0% | grouped_topk_null_sort_key:296 | candidate_implementation_bug:296 |
| datafusion_cross | null_agg_topk | 1011 | 500 | 301 | 301 | 60.2% | 1 | 0 | 0 | 50.8% | 32.06 | 0.98 | 0.73 | 0.62 | 4.69 | 0.0% | grouped_topk_null_sort_key:301 | candidate_implementation_bug:301 |
| datafusion_cross | null_agg_topk | 2011 | 500 | 291 | 291 | 58.2% | 4 | 0 | 0 | 52.0% | 32.37 | 0.98 | 0.73 | 0.63 | 4.70 | 0.0% | grouped_topk_null_sort_key:291 | candidate_implementation_bug:291 |
| datafusion_cross | null_agg_topk | 3011 | 500 | 255 | 255 | 51.0% | 0 | 0 | 0 | 49.6% | 32.47 | 0.99 | 0.73 | 0.62 | 4.70 | 0.0% | grouped_topk_null_sort_key:255 | candidate_implementation_bug:255 |
| datafusion_cross | null_agg_topk | 4011 | 500 | 329 | 329 | 65.8% | 0 | 0 | 0 | 40.0% | 32.67 | 0.97 | 0.73 | 0.67 | 4.75 | 0.0% | grouped_topk_null_sort_key:329 | candidate_implementation_bug:329 |

## Aggregates

| target suite | preset | runs | cases | findings | candidate bugs | candidate case % | candidate cases/s | median first candidate | semantic divs | false positives | avg new behavior % | avg cases/s | avg data sensitivity | avg path proxy |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| core_datafusion | null_agg_topk | 5 | 2500 | 1449 | 1449 | 58.0% | 12.94 | 1 | 0 | 0 | 46.5% | 22.32 | 0.98 | 0.73 |
| core_datafusion | null_groupby_topk | 5 | 2500 | 1914 | 1914 | 76.6% | 16.62 | 0 | 0 | 0 | 14.4% | 21.71 | 1.13 | 0.86 |
| datafusion_cross | null_agg_topk | 5 | 2500 | 1472 | 1472 | 58.9% | 18.30 | 1 | 0 | 0 | 46.8% | 31.08 | 0.98 | 0.73 |
| datafusion_cross | null_groupby_topk | 5 | 2500 | 1909 | 1909 | 76.4% | 18.59 | 0 | 0 | 0 | 14.3% | 24.34 | 1.13 | 0.86 |

## Candidate Bug-Family Deduplication

Families are conservatively grouped by `root_cause + suspicious_backends`; metamorphic relation failures are mapped to a co-occurring differential root for the same suspicious backend when one exists. Use this table for paper-level bug-family counts; use finding and case counts above for sensitivity and time-to-first measurements.

| target suite | preset | candidate bug families | top families |
|---|---|---:|---|
| core_datafusion | null_agg_topk | 1 | grouped_topk_null_sort_key@datafusion:1449 |
| core_datafusion | null_groupby_topk | 1 | grouped_topk_null_sort_key@datafusion:1914 |
| datafusion_cross | null_agg_topk | 1 | grouped_topk_null_sort_key@datafusion:1472 |
| datafusion_cross | null_groupby_topk | 1 | grouped_topk_null_sort_key@datafusion:1909 |

## Interpretation Notes

- Compare `baseline` with `no_type_aware` to measure generator validity and useful behavior discovery.
- Compare `baseline` with `no_normalizer` to estimate false-positive pressure from representation differences.
- Compare `baseline` with `no_feedback` to measure whether corpus feedback improves new behavior discovery.
- Compare `baseline` with `metamorphic` to separate cross-engine differential bugs from single-engine relation violations.
- Use `edge_float` separately from `common`; it studies boundary semantics rather than the default common subset.
