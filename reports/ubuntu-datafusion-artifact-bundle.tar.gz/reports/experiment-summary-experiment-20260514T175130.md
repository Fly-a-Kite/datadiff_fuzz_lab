# DataDiffFuzz Experiment Summary

- Manifest: `runs/experiment-20260514T175130.json`
- Runs: 60
- Presets: null_groupby_topk, null_agg_topk, float_group_key, float_group_key_metamorphic
- Seeds: 1, 1001, 2001, 3001, 4001
- Backends: datafusion, duckdb, pandas, polars, polars_lazy, sqlite
- Target suite: core_datafusion,core_lazy,datafusion_cross
- Target suites: core_datafusion, core_lazy, datafusion_cross
- Target families: dataframe:3; embedded_sql:2; query_engine:1
- Common target capabilities: 23
- Aggregate CSV: `/root/datadiff_fuzz_lab/reports/experiment-summary-experiment-20260514T175130-aggregates.csv`
- Triage columns distinguish candidate implementation bugs from documented/expected semantic divergences and oracle false positives.
- Refreshed with current oracle: yes

## Runs

| target suite | preset | seed | cases | findings | candidate bugs | candidate case % | first candidate | semantic divs | false positives | new behavior % | cases/s | data sensitivity | path proxy | frontier | contribution | pruned % | roots | triage |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|---|
| core_datafusion | null_groupby_topk | 1 | 1000 | 760 | 760 | 76.0% | 0 | 0 | 0 | 9.7% | 21.24 | 1.12 | 0.83 | 0.60 | 4.42 | 0.0% | grouped_topk_null_sort_key:760 | candidate_implementation_bug:760 |
| core_datafusion | null_groupby_topk | 1001 | 1000 | 791 | 791 | 79.1% | 0 | 0 | 0 | 10.5% | 21.00 | 1.14 | 0.83 | 0.60 | 4.42 | 0.0% | grouped_topk_null_sort_key:791 | candidate_implementation_bug:791 |
| core_datafusion | null_groupby_topk | 2001 | 1000 | 752 | 752 | 75.2% | 0 | 0 | 0 | 10.5% | 21.13 | 1.12 | 0.83 | 0.61 | 4.43 | 0.0% | grouped_topk_null_sort_key:752 | candidate_implementation_bug:752 |
| core_datafusion | null_groupby_topk | 3001 | 1000 | 745 | 745 | 74.5% | 0 | 0 | 0 | 10.7% | 20.84 | 1.12 | 0.83 | 0.59 | 4.41 | 0.0% | grouped_topk_null_sort_key:745 | candidate_implementation_bug:745 |
| core_datafusion | null_groupby_topk | 4001 | 1000 | 749 | 749 | 74.9% | 0 | 0 | 0 | 10.6% | 21.03 | 1.12 | 0.83 | 0.60 | 4.42 | 0.0% | grouped_topk_null_sort_key:749 | candidate_implementation_bug:749 |
| core_datafusion | null_agg_topk | 1 | 1000 | 628 | 628 | 62.8% | 1 | 0 | 0 | 42.4% | 21.63 | 0.98 | 0.71 | 0.61 | 4.66 | 0.0% | grouped_topk_null_sort_key:628 | candidate_implementation_bug:628 |
| core_datafusion | null_agg_topk | 1001 | 1000 | 567 | 567 | 56.7% | 0 | 0 | 0 | 37.7% | 21.45 | 1.01 | 0.70 | 0.61 | 4.67 | 0.0% | grouped_topk_null_sort_key:567 | candidate_implementation_bug:567 |
| core_datafusion | null_agg_topk | 2001 | 1000 | 569 | 569 | 56.9% | 9 | 0 | 0 | 44.2% | 21.67 | 0.98 | 0.71 | 0.62 | 4.68 | 0.0% | grouped_topk_null_sort_key:569 | candidate_implementation_bug:569 |
| core_datafusion | null_agg_topk | 3001 | 1000 | 612 | 612 | 61.2% | 1 | 0 | 0 | 43.1% | 21.43 | 0.98 | 0.70 | 0.62 | 4.68 | 0.0% | grouped_topk_null_sort_key:612 | candidate_implementation_bug:612 |
| core_datafusion | null_agg_topk | 4001 | 1000 | 558 | 558 | 55.8% | 0 | 0 | 0 | 44.1% | 21.72 | 0.97 | 0.71 | 0.61 | 4.67 | 0.0% | grouped_topk_null_sort_key:558 | candidate_implementation_bug:558 |
| core_datafusion | float_group_key | 1 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 24.8% | 13.56 | 1.44 | 0.94 | 0.74 | 5.83 | 0.0% | none | none |
| core_datafusion | float_group_key | 1001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 20.6% | 13.46 | 1.44 | 0.90 | 0.75 | 5.86 | 0.0% | none | none |
| core_datafusion | float_group_key | 2001 | 1000 | 1 | 1 | 0.1% | 867 | 0 | 0 | 25.0% | 13.43 | 1.44 | 0.93 | 0.74 | 5.85 | 0.0% | grouped_topk_null_sort_key:1 | candidate_implementation_bug:1 |
| core_datafusion | float_group_key | 3001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 30.7% | 13.62 | 1.44 | 0.94 | 0.76 | 5.85 | 0.0% | none | none |
| core_datafusion | float_group_key | 4001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 26.0% | 13.51 | 1.44 | 0.94 | 0.74 | 5.85 | 0.0% | none | none |
| core_datafusion | float_group_key_metamorphic | 1 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 24.8% | 1.59 | 1.44 | 0.94 | 0.74 | 5.83 | 0.0% | none | none |
| core_datafusion | float_group_key_metamorphic | 1001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 20.6% | 1.57 | 1.44 | 0.90 | 0.75 | 5.86 | 0.0% | none | none |
| core_datafusion | float_group_key_metamorphic | 2001 | 1000 | 1 | 1 | 0.1% | 867 | 0 | 0 | 25.0% | 1.56 | 1.44 | 0.93 | 0.74 | 5.85 | 0.0% | grouped_topk_null_sort_key:1 | candidate_implementation_bug:1 |
| core_datafusion | float_group_key_metamorphic | 3001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 30.7% | 1.61 | 1.44 | 0.94 | 0.76 | 5.85 | 0.0% | none | none |
| core_datafusion | float_group_key_metamorphic | 4001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 26.0% | 1.58 | 1.44 | 0.94 | 0.74 | 5.85 | 0.0% | none | none |
| core_lazy | null_groupby_topk | 1 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 12.3% | 25.63 | 1.15 | 0.82 | 0.60 | 4.42 | 0.0% | none | none |
| core_lazy | null_groupby_topk | 1001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 10.5% | 26.27 | 1.13 | 0.83 | 0.59 | 4.41 | 0.0% | none | none |
| core_lazy | null_groupby_topk | 2001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 9.5% | 26.08 | 1.13 | 0.84 | 0.60 | 4.42 | 0.0% | none | none |
| core_lazy | null_groupby_topk | 3001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 11.4% | 26.45 | 1.13 | 0.84 | 0.59 | 4.41 | 0.0% | none | none |
| core_lazy | null_groupby_topk | 4001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 11.3% | 26.10 | 1.14 | 0.83 | 0.60 | 4.41 | 0.0% | none | none |
| core_lazy | null_agg_topk | 1 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 46.3% | 25.94 | 0.97 | 0.71 | 0.63 | 4.69 | 0.0% | none | none |
| core_lazy | null_agg_topk | 1001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 45.4% | 26.29 | 0.97 | 0.71 | 0.63 | 4.69 | 0.0% | none | none |
| core_lazy | null_agg_topk | 2001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 46.9% | 26.44 | 0.97 | 0.71 | 0.65 | 4.71 | 0.0% | none | none |
| core_lazy | null_agg_topk | 3001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 45.3% | 26.85 | 0.98 | 0.71 | 0.63 | 4.70 | 0.0% | none | none |
| core_lazy | null_agg_topk | 4001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 43.8% | 26.63 | 0.96 | 0.71 | 0.63 | 4.69 | 0.0% | none | none |
| core_lazy | float_group_key | 1 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 24.8% | 16.95 | 1.44 | 0.94 | 0.74 | 5.83 | 0.0% | none | none |
| core_lazy | float_group_key | 1001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 20.6% | 16.75 | 1.44 | 0.90 | 0.75 | 5.86 | 0.0% | none | none |
| core_lazy | float_group_key | 2001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 24.7% | 16.72 | 1.44 | 0.93 | 0.74 | 5.85 | 0.0% | none | none |
| core_lazy | float_group_key | 3001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 30.7% | 17.08 | 1.44 | 0.94 | 0.76 | 5.85 | 0.0% | none | none |
| core_lazy | float_group_key | 4001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 26.0% | 16.90 | 1.44 | 0.94 | 0.74 | 5.85 | 0.0% | none | none |
| core_lazy | float_group_key_metamorphic | 1 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 24.8% | 2.01 | 1.44 | 0.94 | 0.74 | 5.83 | 0.0% | none | none |
| core_lazy | float_group_key_metamorphic | 1001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 20.6% | 1.98 | 1.44 | 0.90 | 0.75 | 5.86 | 0.0% | none | none |
| core_lazy | float_group_key_metamorphic | 2001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 24.7% | 1.97 | 1.44 | 0.93 | 0.74 | 5.85 | 0.0% | none | none |
| core_lazy | float_group_key_metamorphic | 3001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 30.7% | 2.03 | 1.44 | 0.94 | 0.76 | 5.85 | 0.0% | none | none |
| core_lazy | float_group_key_metamorphic | 4001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 26.0% | 2.01 | 1.44 | 0.94 | 0.74 | 5.85 | 0.0% | none | none |
| datafusion_cross | null_groupby_topk | 1 | 1000 | 756 | 756 | 75.6% | 0 | 0 | 0 | 9.9% | 24.50 | 1.12 | 0.83 | 0.60 | 4.42 | 0.0% | grouped_topk_null_sort_key:756 | candidate_implementation_bug:756 |
| datafusion_cross | null_groupby_topk | 1001 | 1000 | 790 | 790 | 79.0% | 0 | 0 | 0 | 9.9% | 26.53 | 1.14 | 0.83 | 0.60 | 4.42 | 0.0% | grouped_topk_null_sort_key:790 | candidate_implementation_bug:790 |
| datafusion_cross | null_groupby_topk | 2001 | 1000 | 756 | 756 | 75.6% | 0 | 0 | 0 | 10.2% | 26.45 | 1.12 | 0.83 | 0.61 | 4.43 | 0.0% | grouped_topk_null_sort_key:756 | candidate_implementation_bug:756 |
| datafusion_cross | null_groupby_topk | 3001 | 1000 | 755 | 755 | 75.5% | 0 | 0 | 0 | 11.7% | 26.75 | 1.12 | 0.83 | 0.59 | 4.41 | 0.0% | grouped_topk_null_sort_key:755 | candidate_implementation_bug:755 |
| datafusion_cross | null_groupby_topk | 4001 | 1000 | 741 | 741 | 74.1% | 0 | 0 | 0 | 10.6% | 26.84 | 1.12 | 0.83 | 0.60 | 4.42 | 0.0% | grouped_topk_null_sort_key:741 | candidate_implementation_bug:741 |
| datafusion_cross | null_agg_topk | 1 | 1000 | 629 | 629 | 62.9% | 1 | 0 | 0 | 42.7% | 28.24 | 0.98 | 0.71 | 0.60 | 4.66 | 0.0% | grouped_topk_null_sort_key:629 | candidate_implementation_bug:629 |
| datafusion_cross | null_agg_topk | 1001 | 1000 | 576 | 576 | 57.6% | 0 | 0 | 0 | 37.6% | 28.60 | 1.00 | 0.70 | 0.61 | 4.67 | 0.0% | grouped_topk_null_sort_key:576 | candidate_implementation_bug:576 |
| datafusion_cross | null_agg_topk | 2001 | 1000 | 574 | 574 | 57.4% | 9 | 0 | 0 | 42.5% | 28.99 | 0.98 | 0.71 | 0.62 | 4.68 | 0.0% | grouped_topk_null_sort_key:574 | candidate_implementation_bug:574 |
| datafusion_cross | null_agg_topk | 3001 | 1000 | 621 | 621 | 62.1% | 1 | 0 | 0 | 42.2% | 28.85 | 0.98 | 0.70 | 0.62 | 4.68 | 0.0% | grouped_topk_null_sort_key:621 | candidate_implementation_bug:621 |
| datafusion_cross | null_agg_topk | 4001 | 1000 | 570 | 570 | 57.0% | 0 | 0 | 0 | 44.7% | 29.55 | 0.97 | 0.71 | 0.62 | 4.68 | 0.0% | grouped_topk_null_sort_key:570 | candidate_implementation_bug:570 |
| datafusion_cross | float_group_key | 1 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 24.8% | 15.23 | 1.44 | 0.94 | 0.74 | 5.83 | 0.0% | none | none |
| datafusion_cross | float_group_key | 1001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 20.6% | 15.35 | 1.44 | 0.90 | 0.75 | 5.86 | 0.0% | none | none |
| datafusion_cross | float_group_key | 2001 | 1000 | 1 | 1 | 0.1% | 867 | 0 | 0 | 25.0% | 15.18 | 1.44 | 0.93 | 0.74 | 5.85 | 0.0% | grouped_topk_null_sort_key:1 | candidate_implementation_bug:1 |
| datafusion_cross | float_group_key | 3001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 30.7% | 15.33 | 1.44 | 0.94 | 0.76 | 5.85 | 0.0% | none | none |
| datafusion_cross | float_group_key | 4001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 26.0% | 15.35 | 1.44 | 0.94 | 0.74 | 5.85 | 0.0% | none | none |
| datafusion_cross | float_group_key_metamorphic | 1 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 24.8% | 1.82 | 1.44 | 0.94 | 0.74 | 5.83 | 0.0% | none | none |
| datafusion_cross | float_group_key_metamorphic | 1001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 20.6% | 1.81 | 1.44 | 0.90 | 0.75 | 5.86 | 0.0% | none | none |
| datafusion_cross | float_group_key_metamorphic | 2001 | 1000 | 1 | 1 | 0.1% | 867 | 0 | 0 | 25.0% | 1.81 | 1.44 | 0.93 | 0.74 | 5.85 | 0.0% | grouped_topk_null_sort_key:1 | candidate_implementation_bug:1 |
| datafusion_cross | float_group_key_metamorphic | 3001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 30.7% | 1.84 | 1.44 | 0.94 | 0.76 | 5.85 | 0.0% | none | none |
| datafusion_cross | float_group_key_metamorphic | 4001 | 1000 | 0 | 0 | 0.0% |  | 0 | 0 | 26.0% | 1.83 | 1.44 | 0.94 | 0.74 | 5.85 | 0.0% | none | none |

## Aggregates

| target suite | preset | runs | cases | findings | candidate bugs | candidate case % | candidate cases/s | median first candidate | semantic divs | false positives | avg new behavior % | avg cases/s | avg data sensitivity | avg path proxy |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| core_datafusion | float_group_key | 5 | 5000 | 1 | 1 | 0.0% | 0.00 | 867 | 0 | 0 | 25.4% | 13.52 | 1.44 | 0.93 |
| core_datafusion | float_group_key_metamorphic | 5 | 5000 | 1 | 1 | 0.0% | 0.00 | 867 | 0 | 0 | 25.4% | 1.58 | 1.44 | 0.93 |
| core_datafusion | null_agg_topk | 5 | 5000 | 2934 | 2934 | 58.7% | 12.66 | 1 | 0 | 0 | 42.3% | 21.58 | 0.98 | 0.71 |
| core_datafusion | null_groupby_topk | 5 | 5000 | 3797 | 3797 | 75.9% | 15.98 | 0 | 0 | 0 | 10.4% | 21.05 | 1.13 | 0.83 |
| core_lazy | float_group_key | 5 | 5000 | 0 | 0 | 0.0% | 0.00 |  | 0 | 0 | 25.4% | 16.88 | 1.44 | 0.93 |
| core_lazy | float_group_key_metamorphic | 5 | 5000 | 0 | 0 | 0.0% | 0.00 |  | 0 | 0 | 25.4% | 2.00 | 1.44 | 0.93 |
| core_lazy | null_agg_topk | 5 | 5000 | 0 | 0 | 0.0% | 0.00 |  | 0 | 0 | 45.5% | 26.43 | 0.97 | 0.71 |
| core_lazy | null_groupby_topk | 5 | 5000 | 0 | 0 | 0.0% | 0.00 |  | 0 | 0 | 11.0% | 26.10 | 1.14 | 0.83 |
| datafusion_cross | float_group_key | 5 | 5000 | 1 | 1 | 0.0% | 0.00 | 867 | 0 | 0 | 25.4% | 15.29 | 1.44 | 0.93 |
| datafusion_cross | float_group_key_metamorphic | 5 | 5000 | 1 | 1 | 0.0% | 0.00 | 867 | 0 | 0 | 25.4% | 1.82 | 1.44 | 0.93 |
| datafusion_cross | null_agg_topk | 5 | 5000 | 2970 | 2970 | 59.4% | 17.14 | 1 | 0 | 0 | 41.9% | 28.85 | 0.98 | 0.71 |
| datafusion_cross | null_groupby_topk | 5 | 5000 | 3798 | 3798 | 76.0% | 19.91 | 0 | 0 | 0 | 10.5% | 26.21 | 1.12 | 0.83 |

## Candidate Bug-Family Deduplication

Families are conservatively grouped by `root_cause + suspicious_backends`; metamorphic relation failures are mapped to a co-occurring differential root for the same suspicious backend when one exists. Use this table for paper-level bug-family counts; use finding and case counts above for sensitivity and time-to-first measurements.

| target suite | preset | candidate bug families | top families |
|---|---|---:|---|
| core_datafusion | float_group_key | 1 | grouped_topk_null_sort_key@datafusion:1 |
| core_datafusion | float_group_key_metamorphic | 1 | grouped_topk_null_sort_key@datafusion:1 |
| core_datafusion | null_agg_topk | 1 | grouped_topk_null_sort_key@datafusion:2934 |
| core_datafusion | null_groupby_topk | 1 | grouped_topk_null_sort_key@datafusion:3797 |
| core_lazy | float_group_key | 0 | none |
| core_lazy | float_group_key_metamorphic | 0 | none |
| core_lazy | null_agg_topk | 0 | none |
| core_lazy | null_groupby_topk | 0 | none |
| datafusion_cross | float_group_key | 1 | grouped_topk_null_sort_key@datafusion:1 |
| datafusion_cross | float_group_key_metamorphic | 1 | grouped_topk_null_sort_key@datafusion:1 |
| datafusion_cross | null_agg_topk | 1 | grouped_topk_null_sort_key@datafusion:2970 |
| datafusion_cross | null_groupby_topk | 1 | grouped_topk_null_sort_key@datafusion:3798 |

## Interpretation Notes

- Compare `baseline` with `no_type_aware` to measure generator validity and useful behavior discovery.
- Compare `baseline` with `no_normalizer` to estimate false-positive pressure from representation differences.
- Compare `baseline` with `no_feedback` to measure whether corpus feedback improves new behavior discovery.
- Compare `baseline` with `metamorphic` to separate cross-engine differential bugs from single-engine relation violations.
- Use `edge_float` separately from `common`; it studies boundary semantics rather than the default common subset.
