# DataDiffFuzz Ablation Audit

- Manifest: `runs/experiment-20260514T190631.json`
- Aggregate CSV: `/root/datadiff_fuzz_lab/reports/experiment-summary-experiment-20260514T190631-aggregates.csv`
- Trusted presets: `baseline,guided,no_feedback,metamorphic`
- Ablation presets: `no_type_aware,no_normalizer`

## Soundness Boundary

Trusted presets executed 60000 cases with 0 oracle false positives. Ablation presets executed 30000 cases with 4128 oracle false positives.

## Preset Totals

| preset | cases | findings | candidate cases | semantic divergences | false positives |
|---|---:|---:|---:|---:|---:|
| baseline | 15000 | 2 | 2 | 0 | 0 |
| guided | 15000 | 2 | 2 | 0 | 0 |
| metamorphic | 15000 | 2 | 2 | 0 | 0 |
| no_feedback | 15000 | 2 | 2 | 0 | 0 |
| no_normalizer | 15000 | 4131 | 1 | 0 | 4128 |
| no_type_aware | 15000 | 183 | 52 | 131 | 0 |

## Candidate Family Audit

| family | status | trusted count | ablation count | total count | presets | target suites |
|---|---|---:|---:|---:|---|---|
| arithmetic_expression@datafusion | ablation_only_do_not_count_without_triage | 0 | 1 | 1 | no_type_aware | datafusion_cross |
| arithmetic_expression@duckdb | ablation_only_do_not_count_without_triage | 0 | 1 | 1 | no_type_aware | arrow_cross |
| arithmetic_expression@duckdb,pandas,polars,sqlite | ablation_only_do_not_count_without_triage | 0 | 1 | 1 | no_type_aware | core |
| arithmetic_expression@duckdb,sqlite | ablation_only_do_not_count_without_triage | 0 | 2 | 2 | no_type_aware | core_arrow,core_lazy |
| arithmetic_expression@pandas | ablation_only_do_not_count_without_triage | 0 | 1 | 1 | no_type_aware | datafusion_cross |
| arithmetic_expression@sqlite | ablation_only_do_not_count_without_triage | 0 | 15 | 15 | no_type_aware | core,core_arrow,core_datafusion,core_lazy |
| groupby_aggregation@datafusion,duckdb,pandas | ablation_only_do_not_count_without_triage | 0 | 3 | 3 | no_type_aware | datafusion_cross |
| groupby_aggregation@datafusion,duckdb,polars_lazy,sqlite | ablation_only_do_not_count_without_triage | 0 | 2 | 2 | no_type_aware | core_datafusion |
| groupby_aggregation@datafusion,duckdb,sqlite | ablation_only_do_not_count_without_triage | 0 | 1 | 1 | no_type_aware | core_datafusion |
| groupby_aggregation@duckdb | ablation_only_do_not_count_without_triage | 0 | 7 | 7 | no_type_aware | arrow_cross,core_arrow,core_datafusion,datafusion_cross |
| groupby_aggregation@duckdb,polars_lazy,sqlite | ablation_only_do_not_count_without_triage | 0 | 6 | 6 | no_type_aware | core_arrow,core_lazy |
| groupby_aggregation@duckdb,sqlite | ablation_only_do_not_count_without_triage | 0 | 3 | 3 | no_type_aware | core |
| groupby_aggregation@polars_lazy | ablation_only_do_not_count_without_triage | 0 | 3 | 3 | no_type_aware | core_arrow,core_lazy |
| grouped_topk_null_sort_key@datafusion | trusted_and_ablation_detected | 8 | 3 | 11 | baseline,guided,metamorphic,no_feedback,no_normalizer,no_type_aware | core_datafusion,datafusion_cross |
